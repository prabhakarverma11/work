import React from 'react';
import ReactDOM from 'react-dom';
import {Provider} from "react-redux";
import store from "./store";
import Layout from "./components/Layout";

const initialState = window.__INITIAL_STATE__;

function onUpdate(){
    console.log("Hi from onUpdate method of app.js");
}


ReactDOM.render(
    <Provider store={store}>
        <Layout />
    </Provider>,
    document.getElementById('root')
);