import React, {Component,PropTypes} from "react";
import {Link} from "react-router";
export default class SignoutForm extends Component {
    render() {
        const { onSignoutClick } = this.props;

        return (
            <div></div>
        )
    }
}