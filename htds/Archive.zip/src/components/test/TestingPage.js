import React from "react";
const TestingPage = () => {
    return <h1>Hello Testing!</h1>
}


export default TestingPage;