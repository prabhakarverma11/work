module.exports = {
  html: ['src/index.html','src/material.html'],
  options: {
    dest: 'angular'
  }
}
