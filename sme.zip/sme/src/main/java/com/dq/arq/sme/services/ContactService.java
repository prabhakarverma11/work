/**
 * 
 */
package com.dq.arq.sme.services;

/**
 * @author prabhakar
 *
 */
public interface ContactService {

}
