/**
 * 
 */
package com.dq.arq.sme.services;

import org.springframework.stereotype.Service;

/**
 * @author prabhakar
 *
 */
@Service
public class ContactServiceImpl implements ContactService {

}
